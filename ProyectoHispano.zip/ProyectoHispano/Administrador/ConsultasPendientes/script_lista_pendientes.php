<?php
header("Content-Type: text/html;charset=utf-8");

    require_once('../../Conexion/conexion.php');

    $salida = "";
    $query = "SELECT estatus,estatusb,estatusc, matriculau,nombre,grupo, generacion FROM usuario WHERE nivel='1' ORDER BY generacion ASC";

    if(isset($_POST['consulta'])){
        $lista = mysqli_real_escape_string($conexion, $_POST['consulta']);
        $query = "SELECT estatus,estatusb,estatusc, matriculau, nombre, grupo, generacion FROM usuario WHERE id LIKE '%".$lista."%'  OR matriculau LIKE '%".$lista."%' OR nombre LIKE '%".$lista."%' OR grupo LIKE '%".$lista."%' OR generacion LIKE '%".$lista."%' AND nivel='1'";
    }

    $resultado = mysqli_query($conexion, $query);
	$row_ver = mysqli_fetch_assoc($resultado);
	$filas = mysqli_num_rows($resultado);




?>

   <table class="table table-bordered" width='950' border='1' align='center'>
            <tr>


                  <td class='Estilo1'><div align='center'>MATRICULA</td>
                <td class='Estilo1'><div align='center'>NOMBRE COMPLETO</td>
                <td class='Estilo1'><div align='center'>GRUPO</td>
                <td class='Estilo1'><div align='center'>GENERACIÓN</td>
                <td class='Estilo1' colspan="2"><div align='center'>FASE A</td>
                <td class='Estilo1' colspan="2"><div align='center'>FASE B</td>
                <td class='Estilo1' colspan="2"><div align='center'>FASE C</td>

            </tr>


              <?php do { ?>


               <tr>

                <td height='25' class='Estilo3'><?php echo $row_ver['matriculau'];?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['nombre']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['grupo']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['generacion']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['estatus']; ?></td>
                <td height="25" class="Estilo3"><a href="../Operaciones/eliminar_FA.php?matriculau=<?php echo $row_ver['matriculau']; ?>">Eliminar<a/></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['estatusb']; ?></td>
                <td height="25" class="Estilo3"><a href="../Operaciones/eliminar_FB.php?matriculau=<?php echo $row_ver['matriculau']; ?>">Eliminar<a/></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['estatusc']; ?></td>
                <td height="25" class="Estilo3"><a href="../Operaciones/eliminar_FC.php?matriculau=<?php echo $row_ver['matriculau']; ?>">Eliminar<a/></td>



            </tr>
          <?php } while($row_ver = mysqli_fetch_assoc($resultado));  ?>
</table>
