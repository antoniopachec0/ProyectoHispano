<?php require_once('../../Conexion/conexion.php') ?>


<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>
<?php
$q_empleo = "SELECT COUNT(*) as tot1 FROM encuestados_si WHERE generacionA='$gen'";
$empleo = mysqli_query($conexion, $q_empleo);
$row_empleo = mysqli_fetch_assoc($empleo);
 ?>
 <?php

 $q_noempleo = "SELECT COUNT(*) as tot2 FROM encuestados_no WHERE generacionN='$gen'";
 $noempleo = mysqli_query($conexion, $q_noempleo);
 $row_noempleo = mysqli_fetch_assoc($noempleo);
  ?>
<?php
$porciento = ($row_empleo['tot1']*100)/$row_Conteo['tot'];
$porciento2 = ($row_noempleo['tot2']*100)/$row_Conteo['tot'];

$num = ($porciento * $row_Conteo['tot'])/100;
//echo $num;
$num1 = ($porciento2 * $row_Conteo['tot'])/100;
//echo $num1;
 ?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Reporte de alumnos con empleo y sin empleo de la Fase A <br> De un total de <?php echo $row_Conteo['tot']; ?> alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Alumnos con empleo <?php echo round($porciento, 1)  ?> % <br> <?php echo $num ?> alumnos', <?php echo $num ?> ],
            ['Alumnos sin empleo <?php echo round($porciento2, 1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo $num1 ?> ],

        ]
    }]
});
		</script>
	</body>
</html>
