<?php require_once('../../Conexion/conexion.php') ?>
<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>

<?php ///////////////////////////////NIVEL DE ENSEÑANZA DE LOS MAESTROS//////////////////////////////////// ?>

<?php
$q_Nivel_maestros_5 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_ense_maestros='5')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_ense_maestros='5')) as tot38";
$Nivel_maestros_5 = mysqli_query($conexion, $q_Nivel_maestros_5);
$row_Nivel_maestros_5 = mysqli_fetch_assoc($Nivel_maestros_5);
$porcientoNivel_maestros_5 = ($row_Nivel_maestros_5['tot38']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_maestros_6 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_ense_maestros='6')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_ense_maestros='6')) as tot39";
$Nivel_maestros_6 = mysqli_query($conexion, $q_Nivel_maestros_6);
$row_Nivel_maestros_6 = mysqli_fetch_assoc($Nivel_maestros_6);
$porcientoNivel_maestros_6 = ($row_Nivel_maestros_6['tot39']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_maestros_7 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_ense_maestros='7')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_ense_maestros='7')) as tot40";
$Nivel_maestros_7 = mysqli_query($conexion, $q_Nivel_maestros_7);
$row_Nivel_maestros_7 = mysqli_fetch_assoc($Nivel_maestros_7);
$porcientoNivel_maestros_7 = ($row_Nivel_maestros_7['tot40']*100)/$row_Conteo['tot'];
?>


<?php
$q_Nivel_maestros_8 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_ense_maestros='8')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_ense_maestros='8')) as tot41";
$Nivel_maestros_8 = mysqli_query($conexion, $q_Nivel_maestros_8);
$row_Nivel_maestros_8 = mysqli_fetch_assoc($Nivel_maestros_8);
$porcientoNivel_maestros_8 = ($row_Nivel_maestros_8['tot41']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_maestros_9 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_ense_maestros='9')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_ense_maestros='9')) as tot42";
$Nivel_maestros_9 = mysqli_query($conexion, $q_Nivel_maestros_9);
$row_Nivel_maestros_9 = mysqli_fetch_assoc($Nivel_maestros_9);
$porcientoNivel_maestros_9 = ($row_Nivel_maestros_9['tot42']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_maestros_10 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_ense_maestros='10')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_ense_maestros='10')) as tot43";
$Nivel_maestros_10 = mysqli_query($conexion, $q_Nivel_maestros_10);
$row_Nivel_maestros_10 = mysqli_fetch_assoc($Nivel_maestros_10);
$porcientoNivel_maestros_10 = ($row_Nivel_maestros_10['tot43']*100)/$row_Conteo['tot'];

$num = ($porcientoNivel_maestros_5 * $row_Conteo['tot'])/100;
$num1 = ($porcientoNivel_maestros_6 * $row_Conteo['tot'])/100;
$num2 = ($porcientoNivel_maestros_7 * $row_Conteo['tot'])/100;
$num3 = ($porcientoNivel_maestros_8 * $row_Conteo['tot'])/100;
$num4 = ($porcientoNivel_maestros_9 * $row_Conteo['tot'])/100;
$num5 = ($porcientoNivel_maestros_10 * $row_Conteo['tot'])/100;
?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Calificaciones de los alumnos para el nivel de eseñanza de los maestros <br> De un total de <?php echo $row_Conteo['tot']; ?> de alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['5 de califición <?php echo round($porcientoNivel_maestros_5,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoNivel_maestros_5,1) ?> ],
            ['6 de califición <?php echo round($porcientoNivel_maestros_6,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientoNivel_maestros_6,1) ?> ],
            ['7 de califición <?php echo round($porcientoNivel_maestros_7,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientoNivel_maestros_7,1) ?> ],
            ['8 de califición <?php echo round($porcientoNivel_maestros_8,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientoNivel_maestros_8,1) ?> ],
            ['9 de califición <?php echo round($porcientoNivel_maestros_9,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientoNivel_maestros_9,1) ?> ],
            ['10 de califición <?php echo round($porcientoNivel_maestros_10,1) ?> % <br> <?php echo $num5 ?> alumnos', <?php echo round($porcientoNivel_maestros_10,1) ?> ],

        ]
    }]
});
		</script>
	</body>
</html>
