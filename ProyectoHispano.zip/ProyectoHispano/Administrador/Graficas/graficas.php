<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sistema</title>
<link href="../../CSS/estilo.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../../bootstrap3/css/bootstrap.css">
<link rel="stylesheet" href="../../CSS/jquery-ui.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="../../JS/jquery-3.3.1.js"></script>
<script src="../../JS/jquery-ui.js"></script>

<style>


	.Estilo1 {font-size: 12px}
	.Estilo3 {font-size: 12px; background: #FFF; color: #000000; text-align: center;}
	.Estilo {font-size: 16px;}
  span{
    font-size: 10pt;
    color: #fff;;

  }
</style>

</head>

<body>
<div id="borde">
<div id="contenedor">

<div id="cabecera">
  <img src="../../Imagenes/HispanoLogo.png"  alt="Sistema de Inventario" border="3" class="imagen" /></div>
  <div id="cuerpo1">
  <br><br><br>
 <h2>ADMINISTRADOR HACER CLICK SOBRE EL BOTON DE LA OPCIÓN DESEADA:</h2>

 </div>
 <div class="contenedor1">
   <center>
     <div id="boxGrafica"><br><br>
			 <table width="600" height="20" border="1" align="center">
		      <tr>
		        <td class="border-td" height="20" style="background:#91010e;"><center><span>Alumnos clasificados por género</span></center></td>
		        <td class="border-td" style="background:#91010e";><center><span>Alumnos clasificados por modalidad</span></center></td>
		      </tr>
		      <tr>
		        <td class="border-td" height="50" ><center><a href="inputGen.php" class="btn btn-danger">Ver gráfica</a></center></td>
		        <td class="border-td"><center><a href="inputModa.php" class="btn btn-danger">Ver gráfica</a></center></td>
		      </tr>
		   </table><br><br>
   <table width="900" height="20" border="1" align="center">
      <tr>
        <td class="border-td" height="20" style="background:#91010e;"><center><span>Total de alumnos empleados y desempleados</span></center></td>
        <td class="border-td" style="background:#91010e";><center><span>Medio para conseguir empleo</span></center></td>
        <td class="border-td" style="background:#91010e";><center><span>Cómo evaluan los alumnos el plan de estudios</span></center></td>
      </tr>
      <tr>
        <td class="border-td" height="50" ><center><a href="inputEmpleoA.php" class="btn btn-danger">Ver gráfica</a></center></td>
        <td class="border-td"><center><a href="inputRequisito.php" class="btn btn-danger">Ver gráfica</a></center></td>
        <td class="border-td"><center><a href="inputComoEvaluas.php" class="btn btn-danger">Ver gráfica</a></center></td>
      </tr>
   </table>
   <br><br>
   <h2>SUGERENCIAS DE LOS ALUMNOS A LA INSTITUCIÓN</h2>
   <table width="900" height="20" border="1" align="center">
      <tr>
        <td class="border-td" height="20" style="background:#91010e;"><center><span>Contenidos teóricos</span></center></td>
        <td class="border-td" style="background:#91010e";><center><span>Contenidos metodológicos</span></center></td>
        <td class="border-td" style="background:#91010e";><center><span>Técnicas relacionadas con la carrera</span></center></td>
        <td class="border-td" style="background:#91010e";><center><span>Contenidos prácticos</span></center></td>
      </tr>
      <tr>
        <td class="border-td" height="50" ><center><a href="inputContTeoricos.php" class="btn btn-danger">Ver gráfica</a></center></td>
        <td class="border-td"><center><a href="inputContMeto.php" class="btn btn-danger">Ver gráfica</a></center></td>
        <td class="border-td"><center><a href="inputTecCarrera.php" class="btn btn-danger">Ver gráfica</a></center></td>
        <td class="border-td"><center><a href="inputContPract.php" class="btn btn-danger">Ver gráfica</a></center></td>
      </tr>
   </table>
   <br>
   <table width="1000" height="20" border="1" align="center">
      <tr>
        <td class="border-td" height="20" style="background:#91010e;"><center><span>Propuestas de los alumnos al plan de estudios</span></center></td>
        <td class="border-td" style="background:#91010e";><center><span>Nivel de satisfacción de enseñanza de los maestros</span></center></td>
				<td class="border-td" style="background:#91010e";><center><span>Nivel de satisfacción con las actividades para vincular lo visto en clase con la realidad</span></center></td>
				<td class="border-td" style="background:#91010e";><center><span>Nivel de satisfacción con los aprendizajes logrados</span></center></td>
				<td class="border-td" style="background:#91010e";><center><span>Nivel de satisfacción con las asesorías</span></center></td>
				<td class="border-td" style="background:#91010e";><center><span>Nivel de satisfacción con los recursos utilizados por los maestros</span></center></td>
      </tr>
      <tr>
        <td class="border-td" height="50" ><center><a href="inputPropuesta.php" class="btn btn-danger">Ver gráfica</a></center></td>
        <td class="border-td"><center><a href="inputNivelMtro.php" class="btn btn-danger">Ver gráfica</a></center></td>
				<td class="border-td"><center><a href="inputNivelSatisAct.php" class="btn btn-danger">Ver gráfica</a></center></td>
				<td class="border-td"><center><a href="inputNivelSatisApre.php" class="btn btn-danger">Ver gráfica</a></center></td>
				<td class="border-td"><center><a href="inputNivelAsesoria.php" class="btn btn-danger">Ver gráfica</a></center></td>
				<td class="border-td"><center><a href="inputNivelRecur.php" class="btn btn-danger">Ver gráfica</a></center></td>
      </tr>
   </table>
	 <br>
	 <table width="900" height="20" border="1" align="center">
      <tr>
        <td class="border-td" height="20" style="background:#91010e;"><center><span>Razones por las cuales los alumnos eligieron a la Universidad Hispano</span></center></td>
				<td class="border-td" height="20" style="background:#91010e;"><center><span>Total de empleados y desempleados Fase B</span></center></td>
				<td class="border-td" height="20" style="background:#91010e;"><center><span>Total de empleados y desempleados Fase C</span></center></td>
      </tr>
      <tr>
        <td class="border-td" height="50" ><center><a href="inputRazones.php" class="btn btn-danger">Ver gráfica</a></center></td>
				<td class="border-td" height="50" ><center><a href="inputEmpleoB.php" class="btn btn-danger">Ver gráfica</a></center></td>
				<td class="border-td" height="50" ><center><a href="inputEmpleoC.php" class="btn btn-danger">Ver gráfica</a></center></td>

      </tr>
   </table>
 </div>
 </center>
 </div>
<br><br><br>
<p align="center">Listado de gráficas</p>
<br>

<center>

 <br>



	</center>
  <div id="pie">
  <p align="center"></p>
</div>
<p>&nbsp;</p>

</body>
</html>
