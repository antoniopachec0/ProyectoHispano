<?php require_once('../../Conexion/conexion.php') ?>


<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>

<?php
$q_Cont_teorico = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_teorico='REDUCIR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_teorico='REDUCIR')) as tot13";
$Cont_teorico = mysqli_query($conexion, $q_Cont_teorico);
$row_Cont_teorico = mysqli_fetch_assoc($Cont_teorico);
$porcientoCont_teorico = ($row_Cont_teorico['tot13']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS TEORICOS(ACTUALIZAR)////////////////////////////////////////////////////// ?>

<?php
$q_Cont_teoricoAct = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_teorico='ACTUALIZAR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_teorico='ACTUALIZAR')) as tot14";
$Cont_teoricoAct = mysqli_query($conexion, $q_Cont_teoricoAct);
$row_Cont_teoricoAct = mysqli_fetch_assoc($Cont_teoricoAct);
$porcientoCont_teoricoAct = ($row_Cont_teoricoAct['tot14']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS TEORICOS(MANTENER)////////////////////////////////////////////////////// ?>

<?php
$q_Cont_teoricoMant = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_teorico='MANTENER')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_teorico='MANTENER')) as tot15";
$Cont_teoricoMant = mysqli_query($conexion, $q_Cont_teoricoMant);
$row_Cont_teoricoMant = mysqli_fetch_assoc($Cont_teoricoMant);
$porcientoCont_teoricoMant = ($row_Cont_teoricoMant['tot15']*100)/$row_Conteo['tot'];
?>
<?php //////////////////////////////////CONTENIDOS TEORICOS(AMPLIAR)////////////////////////////////////////////////////// ?>

<?php
$q_Cont_teoricoAmp = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_teorico='AMPLIAR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_teorico='AMPLIAR')) as tot16";
$Cont_teoricoAmp = mysqli_query($conexion, $q_Cont_teoricoAmp);
$row_Cont_teoricoAmp = mysqli_fetch_assoc($Cont_teoricoAmp);
$porcientoCont_teoricoAmp = ($row_Cont_teoricoAmp['tot16']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS TEORICOS(IMPLEMENTAR PRACTICAS)//////////////////////////////////////////////////// ?>

<?php
$q_Cont_teoricoImp = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_teorico='IMPLEMENTAR PRACTICAS')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_teorico='IMPLEMENTAR PRACTICAS')) as tot17";
$Cont_teoricoImp = mysqli_query($conexion, $q_Cont_teoricoImp);
$row_Cont_teoricoImp = mysqli_fetch_assoc($Cont_teoricoImp);
$porcientoCont_teoricoImp = ($row_Cont_teoricoImp['tot17']*100)/$row_Conteo['tot'];

$num = ($porcientoCont_teorico * $row_Conteo['tot'])/100;
$num1 = ($porcientoCont_teoricoAct * $row_Conteo['tot'])/100;
$num2 = ($porcientoCont_teoricoMant * $row_Conteo['tot'])/100;
$num3 = ($porcientoCont_teoricoAmp * $row_Conteo['tot'])/100;
$num4 = ($porcientoCont_teoricoImp * $row_Conteo['tot'])/100;
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Sugerencias de los alumnos para los contenidos teoricos <br> De un total de <?php echo $row_Conteo['tot']; ?> de alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Reducir <?php echo round($porcientoCont_teorico,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoCont_teorico,1) ?> ],
            ['Actualizar <?php echo round($porcientoCont_teoricoAct,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientoCont_teoricoAct,1) ?> ],
            ['Mantener <?php echo round($porcientoCont_teoricoMant,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientoCont_teoricoMant,1) ?> ],
            ['Ampliar <?php echo round($porcientoCont_teoricoAmp,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientoCont_teoricoAmp,1) ?> ],
            ['Implementar practicas <?php echo round($porcientoCont_teoricoImp,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientoCont_teoricoImp,1) ?> ],


        ]
    }]
});
		</script>
	</body>
</html>
