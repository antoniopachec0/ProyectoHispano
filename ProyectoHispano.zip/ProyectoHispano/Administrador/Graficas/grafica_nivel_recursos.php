<?php require_once('../../Conexion/conexion.php') ?>
<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>
<?php ////////////////////////////////SATISFACCION DE RECURSOS////////////////////////////////// ?>

<?php
$q_Nivel_recursos_5 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_satisfaccion_recursos='5')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_satisfaccion_recursos='5')) as tot62";
$Nivel_recursos_5 = mysqli_query($conexion, $q_Nivel_recursos_5);
$row_Nivel_recursos_5 = mysqli_fetch_assoc($Nivel_recursos_5);
$porcientoNivel_recursos_5 = ($row_Nivel_recursos_5['tot62']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_recursos_6 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_satisfaccion_recursos='6')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_satisfaccion_recursos='6')) as tot63";
$Nivel_recursos_6 = mysqli_query($conexion, $q_Nivel_recursos_6);
$row_Nivel_recursos_6 = mysqli_fetch_assoc($Nivel_recursos_6);
$porcientoNivel_recursos_6 = ($row_Nivel_recursos_6['tot63']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_recursos_7 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_satisfaccion_recursos='7')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_satisfaccion_recursos='7')) as tot64";
$Nivel_recursos_7 = mysqli_query($conexion, $q_Nivel_recursos_7);
$row_Nivel_recursos_7 = mysqli_fetch_assoc($Nivel_recursos_7);
$porcientoNivel_recursos_7 = ($row_Nivel_recursos_7['tot64']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_recursos_8 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_satisfaccion_recursos='8')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_satisfaccion_recursos='8')) as tot65";
$Nivel_recursos_8 = mysqli_query($conexion, $q_Nivel_recursos_8);
$row_Nivel_recursos_8 = mysqli_fetch_assoc($Nivel_recursos_8);
$porcientoNivel_recursos_8 = ($row_Nivel_recursos_8['tot65']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_recursos_9 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_satisfaccion_recursos='9')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_satisfaccion_recursos='9')) as tot66";
$Nivel_recursos_9 = mysqli_query($conexion, $q_Nivel_recursos_9);
$row_Nivel_recursos_9 = mysqli_fetch_assoc($Nivel_recursos_9);
$porcientoNivel_recursos_9 = ($row_Nivel_recursos_9['tot66']*100)/$row_Conteo['tot'];
?>

<?php
$q_Nivel_recursos_10 = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND nivel_satisfaccion_recursos='10')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND nivel_satisfaccion_recursos='10')) as tot67";
$Nivel_recursos_10 = mysqli_query($conexion, $q_Nivel_recursos_10);
$row_Nivel_recursos_10 = mysqli_fetch_assoc($Nivel_recursos_10);
$porcientoNivel_recursos_10 = ($row_Nivel_recursos_10['tot67']*100)/$row_Conteo['tot'];

$num = ($porcientoNivel_recursos_5 * $row_Conteo['tot'])/100;
$num1 = ($porcientoNivel_recursos_6 * $row_Conteo['tot'])/100;
$num2 = ($porcientoNivel_recursos_7 * $row_Conteo['tot'])/100;
$num3 = ($porcientoNivel_recursos_8 * $row_Conteo['tot'])/100;
$num4 = ($porcientoNivel_recursos_9 * $row_Conteo['tot'])/100;
$num5 = ($porcientoNivel_recursos_10 * $row_Conteo['tot'])/100;
?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Calificación de los alumnos a los recursos utlizados por los maestros para apoyar sus explicaciones <br> De un total de <?php echo $row_Conteo['tot']; ?> de alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['5 de califición <?php echo round($porcientoNivel_recursos_5,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoNivel_recursos_5,1) ?> ],
            ['6 de califición <?php echo round($porcientoNivel_recursos_6,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientoNivel_recursos_6,1) ?> ],
            ['7 de califición <?php echo round($porcientoNivel_recursos_7,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientoNivel_recursos_7,1) ?> ],
            ['8 de califición <?php echo round($porcientoNivel_recursos_8,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientoNivel_recursos_8,1) ?> ],
            ['9 de califición <?php echo round($porcientoNivel_recursos_9,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientoNivel_recursos_9,1) ?> ],
            ['10 de califición <?php echo round($porcientoNivel_recursos_10,1) ?> % <br> <?php echo $num5 ?> alumnos', <?php echo round($porcientoNivel_recursos_10,1) ?> ],

        ]
    }]
});
		</script>

	</body>
</html>
