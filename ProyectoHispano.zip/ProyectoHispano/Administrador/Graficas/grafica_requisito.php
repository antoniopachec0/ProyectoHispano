

<?php require_once('../../Conexion/conexion.php') ?>


<?php
$gen = $_POST['gen'];
error_reporting(0);
$q_empleo = "SELECT COUNT(*) as tot1 FROM encuestados_si WHERE generacionA='$gen'";
$empleo = mysqli_query($conexion, $q_empleo);
$row_empleo = mysqli_fetch_assoc($empleo);
 ?>

<?php
$q_titulo = "SELECT COUNT(*) as tot3 FROM encuestados_si WHERE generacionA='$gen' AND requisito='TITULO'";
$titulo = mysqli_query($conexion, $q_titulo);
$row_titulo = mysqli_fetch_assoc($titulo);
$porcientoTitulo = ($row_titulo['tot3']*100)/$row_empleo['tot1'];
?>
<?php /////////////////////////////CARTA DE RECOMENDACION//////////////////////// ?>
<?php
$q_Carta = "SELECT COUNT(*) as tot4 FROM encuestados_si WHERE generacionA='$gen' AND requisito='CARTA DE RECOMENDACION'";
$Carta = mysqli_query($conexion, $q_Carta);
$row_Carta = mysqli_fetch_assoc($Carta);
$porcientoCarta = ($row_Carta['tot4']*100)/$row_empleo['tot1'];
?>

<?php ///////////////////////////EXPERIENCIA///////////////////////////////////// ?>

<?php
$q_Experiencia = "SELECT COUNT(*) as tot5 FROM encuestados_si WHERE generacionA='$gen' AND requisito='EXPERIENCIA EN LA ACTIVIDAD A DESARROLLAR'";
$Experiencia = mysqli_query($conexion, $q_Experiencia);
$row_Experiencia = mysqli_fetch_assoc($Experiencia);
$porcientoExperiencia = ($row_Experiencia['tot5']*100)/$row_empleo['tot1'];
?>

<?php ///////////////////////////////////////CUMPLIR CON EL PROCESO ///////////////////////////////?>

<?php
$q_Cumplir = "SELECT COUNT(*) as tot6 FROM encuestados_si WHERE generacionA='$gen' AND requisito='CUMPLIR CON EL PROCESO DE SELECCION COMPLETO'";
$Cumplir = mysqli_query($conexion, $q_Cumplir);
$row_Cumplir = mysqli_fetch_assoc($Cumplir);
$porcientoCumplir = ($row_Cumplir['tot6']*100)/$row_empleo['tot1'];
?>

<?php /////////////////////////////////////OTRO/////////////////////////////////////////////// ?>

<?php
$q_Otro = "SELECT COUNT(*) as tot7 FROM encuestados_si WHERE generacionA='$gen' AND requisito='OTRO'";
$Otro = mysqli_query($conexion, $q_Otro);
$row_Otro = mysqli_fetch_assoc($Otro);
$porcientoOtro = ($row_Otro['tot7']*100)/$row_empleo['tot1'];

$num = ($porcientoTitulo * $row_empleo['tot1'])/100;
$num1 = ($porcientoCarta * $row_empleo['tot1'])/100;
$num2 = ($porcientoExperiencia * $row_empleo['tot1'])/100;
$num3 = ($porcientoCumplir * $row_empleo['tot1'])/100;
$num4 = ($porcientoOtro * $row_empleo['tot1'])/100;
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Medios por el cual los alumnos encontraron empleo <br> De un total de <?php echo $row_empleo['tot1']; ?> alumnos con empleo'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Titulo <?php echo round($porcientoTitulo,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoTitulo,1) ?> ],
            ['Cartas de recomendación <?php echo round($porcientoCarta,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientoCarta,1) ?> ],
            ['Experiencia en la actividad a desarrollar <?php echo round($porcientoExperiencia,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientoExperiencia,1) ?> ],
            ['Cumplir con el proceso de seleccion compleo <?php echo round($porcientoCumplir,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientoCumplir,1) ?> ],
            ['Otro <?php echo round($porcientoOtro,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientoOtro,1) ?> ],


        ]
    }]
});
		</script>
	</body>
</html>
