<?php require_once('../../Conexion/conexion.php') ?>
<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>
<?php
$q_Excelente = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND como_evaluas='EXCELENTE')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND como_evaluas='EXCELENTE')) as tot8";
$Excelente = mysqli_query($conexion, $q_Excelente);
$row_Excelente = mysqli_fetch_assoc($Excelente);
$porcientoExcelente = ($row_Excelente['tot8']*100)/$row_Conteo['tot'];
?>
<?php /////////////////////////////////MUY BUENO//////////////////////////////////////////////// ?>
<?php
$q_MuyBueno = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND como_evaluas='MUY BUENO')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND como_evaluas='MUY BUENO')) as tot9";
$MuyBueno = mysqli_query($conexion, $q_MuyBueno);
$row_MuyBueno = mysqli_fetch_assoc($MuyBueno);
$porcientoMuyBueno = ($row_MuyBueno['tot9']*100)/$row_Conteo['tot'];
?>
<?php //////////////////////////////BUENO///////////////////////////////////////////////////////// ?>
<?php
$q_Bueno = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND como_evaluas='BUENO')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND como_evaluas='BUENO')) as tot10";
$Bueno = mysqli_query($conexion, $q_Bueno);
$row_Bueno = mysqli_fetch_assoc($Bueno);
$porcientoBueno = ($row_Bueno['tot10']*100)/$row_Conteo['tot'];
?>
<?php //////////////////////////////REGULAR///////////////////////////////////////////////////////// ?>
<?php
$q_Regular = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND como_evaluas='REGULAR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND como_evaluas='REGULAR')) as tot11";
$Regular = mysqli_query($conexion, $q_Regular);
$row_Regular = mysqli_fetch_assoc($Regular);
$porcientoRegular = ($row_Regular['tot11']*100)/$row_Conteo['tot'];
?>
<?php //////////////////////////////OTRO///////////////////////////////////////////////////////// ?>
<?php
$q_Malo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND como_evaluas='MALO')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND como_evaluas='MALO')) as tot12";
$Malo = mysqli_query($conexion, $q_Malo);
$row_Malo = mysqli_fetch_assoc($Malo);
$porcientoMalo = ($row_Malo['tot12']*100)/$row_Conteo['tot'];

$num = ($porcientoExcelente * $row_Conteo['tot'])/100;
$num1 = ($porcientoMuyBueno * $row_Conteo['tot'])/100;
$num2 = ($porcientoBueno * $row_Conteo['tot'])/100;
$num3 = ($porcientoRegular * $row_Conteo['tot'])/100;
$num4 = ($porcientoMalo * $row_Conteo['tot'])/100;
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Como evaluan los alumnos el plan de estudios <br> De un total de <?php echo $row_Conteo['tot']; ?> de alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Excelente <?php echo round($porcientoExcelente,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoExcelente,1) ?> ],
            ['Muy Bueno <?php echo round($porcientoMuyBueno,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientoMuyBueno,1) ?> ],
            ['Bueno <?php echo round($porcientoBueno,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientoBueno,1) ?> ],
            ['Regular <?php echo round($porcientoRegular,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientoRegular,1) ?> ],
            ['Malo <?php echo round($porcientoMalo,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientoMalo,1) ?> ],


        ]
    }]
});
		</script>
	</body>
</html>
