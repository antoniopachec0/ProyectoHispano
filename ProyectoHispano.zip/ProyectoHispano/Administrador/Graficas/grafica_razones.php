<?php require_once('../../Conexion/conexion.php') ?>
<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>
<?php /////////////////////////////////////////RAZONES//////////////////////////////////// ?>

<?php
$q_razones = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND razones='PRESTIGIO DE LA INSTITUCION')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND razones='PRESTIGIO DE LA INSTITUCION')) as tot68";
$razones = mysqli_query($conexion, $q_razones);
$row_razones = mysqli_fetch_assoc($razones);
$porcientorazones = ($row_razones['tot68']*100)/$row_Conteo['tot'];
?>

<?php
$q_razonesMod = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND razones='MODELO ACADEMICO')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND razones='MODELO ACADEMICO')) as tot69";
$razonesMod = mysqli_query($conexion, $q_razonesMod);
$row_razonesMod = mysqli_fetch_assoc($razonesMod);
$porcientorazonesMod = ($row_razonesMod['tot69']*100)/$row_Conteo['tot'];
?>

<?php
$q_razonesUb = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND razones='SU UBICACION')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND razones='SU UBICACION')) as tot70";
$razonesUb = mysqli_query($conexion, $q_razonesUb);
$row_razonesUb = mysqli_fetch_assoc($razonesUb);
$porcientorazonesUb = ($row_razonesUb['tot70']*100)/$row_Conteo['tot'];
?>

<?php
$q_razonesCo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND razones='EL COSTO DE LA COLEGIATURA')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND razones='EL COSTO DE LA COLEGIATURA')) as tot71";
$razonesCo = mysqli_query($conexion, $q_razonesCo);
$row_razonesCo = mysqli_fetch_assoc($razonesCo);
$porcientorazonesCo = ($row_razonesCo['tot71']*100)/$row_Conteo['tot'];
?>

<?php
$q_razonesCons = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND razones='CONSEJO DE PROFESORES')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND razones='CONSEJO DE PROFESORES')) as tot72";
$razonesCons = mysqli_query($conexion, $q_razonesCons);
$row_razonesCons = mysqli_fetch_assoc($razonesCons);
$porcientorazonesCons = ($row_razonesCons['tot72']*100)/$row_Conteo['tot'];
?>

<?php
$q_razonesConsO = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND razones='CONSEJO DE ORIENTADORES EDUCATIVOS')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND razones='CONSEJO DE ORIENTADORES EDUCATIVOS')) as tot73";
$razonesConsO = mysqli_query($conexion, $q_razonesConsO);
$row_razonesConsO = mysqli_fetch_assoc($razonesConsO);
$porcientorazonesConsO = ($row_razonesConsO['tot73']*100)/$row_Conteo['tot'];
?>

<?php
$q_razonesConsOF = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND razones='CONSEJO DE FAMILIARES Y AMIGOS')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND razones='CONSEJO DE FAMILIARES Y AMIGOS')) as tot74";
$razonesConsOF = mysqli_query($conexion, $q_razonesConsOF);
$row_razonesConsOF = mysqli_fetch_assoc($razonesConsOF);
$porcientorazonesConsOF = ($row_razonesConsOF['tot74']*100)/$row_Conteo['tot'];
?>

<?php
$q_razonesConsOT = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND razones='OTRO')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND razones='OTRO')) as tot75";
$razonesConsOT = mysqli_query($conexion, $q_razonesConsOT);
$row_razonesConsOT = mysqli_fetch_assoc($razonesConsOT);
$porcientorazonesConsOT = ($row_razonesConsOT['tot75']*100)/$row_Conteo['tot'];

$num = ($porcientorazones * $row_Conteo['tot'])/100;
$num1 = ($porcientorazonesMod * $row_Conteo['tot'])/100;
$num2 = ($porcientorazonesUb * $row_Conteo['tot'])/100;
$num3 = ($porcientorazonesCo * $row_Conteo['tot'])/100;
$num4 = ($porcientorazonesCons * $row_Conteo['tot'])/100;
$num5 = ($porcientorazonesConsO * $row_Conteo['tot'])/100;
$num6 = ($porcientorazonesConsOF * $row_Conteo['tot'])/100;
$num7 = ($porcientorazonesConsOT * $row_Conteo['tot'])/100;
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Razones por las cuales los alumnos elegieron a la Universidad Hispano <br> De un total de <?php echo $row_Conteo['tot']; ?> alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Prestigio de la Institución <?php echo round($porcientorazones,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientorazones,1) ?> ],
            ['Modelo académico <?php echo round($porcientorazonesMod,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientorazonesMod,1) ?> ],
            ['Su ubicación <?php echo round($porcientorazonesUb,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientorazonesUb,1) ?> ],
            ['El costo de la colegiatura <?php echo round($porcientorazonesCo,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientorazonesCo,1) ?> ],
            ['Consejo de profesores <?php echo round($porcientorazonesCons,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientorazonesCons,1) ?> ],
            ['Consejo de Orientadores educativos <?php echo round($porcientorazonesConsO,1) ?> % <br> <?php echo $num5 ?> alumnos', <?php echo round($porcientorazonesConsO,1) ?> ],
            ['Consejo de familiares y amigos <?php echo round($porcientorazonesConsOF,1) ?> % <br> <?php echo $num6 ?> alumnos', <?php echo round($porcientorazonesConsOF,1) ?> ],
            ['Otro <?php echo round($porcientorazonesConsOT,1) ?> % <br> <?php echo $num7 ?> alumnos', <?php echo round($porcientorazonesConsOT,1) ?> ],

        ]
    }]
});
		</script>
	</body>
</html>
