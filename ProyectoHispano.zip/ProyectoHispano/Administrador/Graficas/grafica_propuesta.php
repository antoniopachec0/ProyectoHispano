<?php require_once('../../Conexion/conexion.php') ?>
<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>

<?php //////////////////////////////////PROPUESTA///////////////////////////////////////////// ?>

<?php
$q_Propuesta = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND propuesta='EXTENSION DE LOS CONTENIDOS')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND propuesta='EXTENSION DE LOS CONTENIDOS')) as tot33";
$Propuesta = mysqli_query($conexion, $q_Propuesta);
$row_Propuesta = mysqli_fetch_assoc($Propuesta);
$porcientoPropuesta = ($row_Propuesta['tot33']*100)/$row_Conteo['tot'];
?>


<?php //////////////////////////////////PROPUESTA///////////////////////////////////////////// ?>

<?php
$q_PropuestaDeForma = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND propuesta='FORMA DE EVALUAR EL APRENDIZAJE')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND propuesta='FORMA DE EVALUAR EL APRENDIZAJE')) as tot34";
$PropuestaDeForma = mysqli_query($conexion, $q_PropuestaDeForma);
$row_PropuestaDeForma = mysqli_fetch_assoc($PropuestaDeForma);
$porcientoPropuestaDeForma = ($row_PropuestaDeForma['tot34']*100)/$row_Conteo['tot'];
?>


<?php //////////////////////////////////PROPUESTA///////////////////////////////////////////// ?>

<?php
$q_PropuestaRefe = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND propuesta='REFERENCIAS BIBLIOGRAFICAS')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND propuesta='REFERENCIAS BIBLIOGRAFICAS')) as tot35";
$PropuestaRefe = mysqli_query($conexion, $q_PropuestaRefe);
$row_PropuestaRefe = mysqli_fetch_assoc($PropuestaRefe);
$porcientoPropuestaRefe = ($row_PropuestaRefe['tot35']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////PROPUESTA///////////////////////////////////////////// ?>

<?php
$q_PropuestaRecur = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND propuesta='RECURSOS TECNOLOGICOS PARA APOYAR EL APRENDIZAJE')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND propuesta='RECURSOS TECNOLOGICOS PARA APOYAR EL APRENDIZAJE')) as tot36";
$PropuestaRecur = mysqli_query($conexion, $q_PropuestaRecur);
$row_PropuestaRecur = mysqli_fetch_assoc($PropuestaRecur);
$porcientoPropuestaRecur = ($row_PropuestaRecur['tot36']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////PROPUESTA///////////////////////////////////////////// ?>

<?php
$q_PropuestaOtro = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND propuesta='OTRO')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND propuesta='OTRO')) as tot37";
$PropuestaOtro = mysqli_query($conexion, $q_PropuestaOtro);
$row_PropuestaOtro = mysqli_fetch_assoc($PropuestaOtro);
$porcientoPropuestaOtro = ($row_PropuestaOtro['tot37']*100)/$row_Conteo['tot'];

$num = ($porcientoPropuesta * $row_Conteo['tot'])/100;
$num1 = ($porcientoPropuestaDeForma * $row_Conteo['tot'])/100;
$num2 = ($porcientoPropuestaRefe * $row_Conteo['tot'])/100;
$num3 = ($porcientoPropuestaRecur * $row_Conteo['tot'])/100;
$num4 = ($porcientoPropuestaOtro * $row_Conteo['tot'])/100;
?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Propuestas de los alumnos al plan de estudios <br> De un total de <?php echo $row_Conteo['tot']; ?> alumnos con empleo'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Extensión de los contenidos <?php echo round($porcientoPropuesta,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoPropuesta,1) ?> ],
            ['Forma de evaluar el aprendizaje <?php echo round($porcientoPropuestaDeForma,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientoPropuestaDeForma,1) ?> ],
            ['Referencias bibliograficas <?php echo round($porcientoPropuestaRefe,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientoPropuestaRefe,1) ?> ],
            ['Recursos tecnológicos para apoyar el aprendizaje <?php echo round($porcientoPropuestaRecur,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientoPropuestaRecur,1) ?> ],
            ['Otro <?php echo round($porcientoPropuestaOtro,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientoPropuestaOtro,1) ?> ],


        ]
    }]
});
		</script>
	</body>
</html>
