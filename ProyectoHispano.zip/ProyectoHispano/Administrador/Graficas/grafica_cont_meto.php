<?php require_once('../../Conexion/conexion.php') ?>


<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>

<?php
$q_Cont_MetoReducir = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_meto='REDUCIR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_meto='REDUCIR')) as tot18";
$Cont_MetoReducir = mysqli_query($conexion, $q_Cont_MetoReducir);
$row_Cont_MetoReducir = mysqli_fetch_assoc($Cont_MetoReducir);
$porcientoCont_MetoReducir = ($row_Cont_MetoReducir['tot18']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS METODOLOGICAS(ACTUALIZAR)///////////////////////////////////////////// ?>

<?php
$q_Cont_MetoActualizar = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_meto='ACTUALIZAR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_meto='ACTUALIZAR')) as tot19";
$Cont_MetoActualizar = mysqli_query($conexion, $q_Cont_MetoActualizar);
$row_Cont_MetoActualizar = mysqli_fetch_assoc($Cont_MetoActualizar);
$porcientoCont_MetoActualizar = ($row_Cont_MetoActualizar['tot19']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS METODOLOGICAS(MANTENER)///////////////////////////////////////////// ?>

<?php
$q_Cont_MetoMantener = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_meto='MANTENER')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_meto='MANTENER')) as tot20";
$Cont_MetoMantener = mysqli_query($conexion, $q_Cont_MetoMantener);
$row_Cont_MetoMantener = mysqli_fetch_assoc($Cont_MetoMantener);
$porcientoCont_MetoMantener = ($row_Cont_MetoMantener['tot20']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS METODOLOGICAS(AMPLIAR)///////////////////////////////////////////// ?>

<?php
$q_Cont_MetoAmpliar = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_meto='AMPLIAR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_meto='AMPLIAR')) as tot21";
$Cont_MetoAmpliar = mysqli_query($conexion, $q_Cont_MetoAmpliar);
$row_Cont_MetoAmpliar = mysqli_fetch_assoc($Cont_MetoAmpliar);
$porcientoCont_MetoAmpliar = ($row_Cont_MetoAmpliar['tot21']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS METODOLOGICAS(IMPLEMENTAR PRACTICAS)///////////////////////////////////////////// ?>

<?php
$q_Cont_MetoImp = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_meto='IMPLEMENTAR PRACTICAS')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_meto='IMPLEMENTAR PRACTICAS')) as tot22";
$Cont_MetoImp = mysqli_query($conexion, $q_Cont_MetoImp);
$row_Cont_MetoImp = mysqli_fetch_assoc($Cont_MetoImp);
$porcientoCont_MetoImp = ($row_Cont_MetoImp['tot22']*100)/$row_Conteo['tot'];

$num = ($porcientoCont_MetoReducir * $row_Conteo['tot'])/100;
$num1 = ($porcientoCont_MetoActualizar * $row_Conteo['tot'])/100;
$num2 = ($porcientoCont_MetoMantener * $row_Conteo['tot'])/100;
$num3 = ($porcientoCont_MetoAmpliar * $row_Conteo['tot'])/100;
$num4 = ($porcientoCont_MetoImp * $row_Conteo['tot'])/100;
?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Sugerencias de los alumnos para los contenidos metodológicos <br> De un total de <?php echo $row_Conteo['tot']; ?> de alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Reducir <?php echo round($porcientoCont_MetoReducir,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoCont_MetoReducir,1) ?> ],
            ['Actualizar <?php echo round($porcientoCont_MetoActualizar,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientoCont_MetoActualizar,1) ?> ],
            ['Mantener <?php echo round($porcientoCont_MetoMantener,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientoCont_MetoMantener,1) ?> ],
            ['Ampliar <?php echo round($porcientoCont_MetoAmpliar,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientoCont_MetoAmpliar,1) ?> ],
            ['Implementar practicas <?php echo round($porcientoCont_MetoImp,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientoCont_MetoImp,1) ?> ],


        ]
    }]
});
		</script>
	</body>
</html>
