<?php require_once('../../Conexion/conexion.php') ?>


<?php
$gen = $_POST['gen'];
error_reporting(0);
$q_ConteoB = "SELECT((SELECT COUNT(*) FROM encuestados_si_b WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no_b WHERE generacionN='$gen')) as tot76";
$conteoB = mysqli_query($conexion, $q_ConteoB);
$row_ConteoB = mysqli_fetch_assoc($conteoB);
?>

<?php
$q_empleoB = "SELECT COUNT(*) as tot77 FROM encuestados_si_b WHERE generacionA='$gen'";
$empleoB = mysqli_query($conexion, $q_empleoB);
$row_empleoB = mysqli_fetch_assoc($empleoB);
 ?>
 <?php

 $q_noempleoB = "SELECT COUNT(*) as tot78 FROM encuestados_no_b WHERE generacionN='$gen'";
 $noempleoB = mysqli_query($conexion, $q_noempleoB);
 $row_noempleoB = mysqli_fetch_assoc($noempleoB);
  ?>
<?php
$porcientoB = ($row_empleoB['tot77']*100)/$row_ConteoB['tot76'];
$porciento2B = ($row_noempleoB['tot78']*100)/$row_ConteoB['tot76'];

$num = ($porcientoB * $row_ConteoB['tot76'])/100;
$num1 = ($porciento2B * $row_ConteoB['tot76'])/100;
 ?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Reporte de alumnos con empleo y sin empleo de la Fase B <br> De un total de <?php echo $row_ConteoB['tot76']; ?> alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Alumnos con empleo <?php echo round($porcientoB, 1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoB, 1) ?> ],
            ['Alumnos sin empleo <?php echo round($porciento2B, 1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porciento2B, 1) ?> ],

        ]
    }]
});
		</script>
	</body>
</html>
