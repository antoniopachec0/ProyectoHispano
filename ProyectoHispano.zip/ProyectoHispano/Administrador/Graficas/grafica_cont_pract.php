<?php require_once('../../Conexion/conexion.php') ?>

<?php

$gen = $_POST['gen'];
error_reporting(0);
$q_Conteo = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen')) as tot";
$conteo = mysqli_query($conexion, $q_Conteo);
$row_Conteo = mysqli_fetch_assoc($conteo);
?>

<?php //////////////////////////////////CONTENIDOS PRACTICOS(REDUCIR)///////////////////////////////////////////// ?>

<?php
$q_Cont_pract_Reducir = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_pract='REDUCIR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_pract='REDUCIR')) as tot28";
$Cont_pract_Reducir = mysqli_query($conexion, $q_Cont_pract_Reducir);
$row_Cont_pract_Reducir = mysqli_fetch_assoc($Cont_pract_Reducir);
$porcientoCont_pract_Reducir = ($row_Cont_pract_Reducir['tot28']*100)/$row_Conteo['tot'];
?>


<?php //////////////////////////////////CONTENIDOS PRACTICOS(ACTUALIZAR)///////////////////////////////////////////// ?>

<?php
$q_Cont_pract_Actualizar = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_pract='ACTUALIZAR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_pract='ACTUALIZAR')) as tot29";
$Cont_pract_Actualizar = mysqli_query($conexion, $q_Cont_pract_Actualizar);
$row_Cont_pract_Actualizar = mysqli_fetch_assoc($Cont_pract_Actualizar);
$porcientoCont_pract_Actualizar = ($row_Cont_pract_Actualizar['tot29']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS PRACTICOS(MANTENER)///////////////////////////////////////////// ?>

<?php
$q_Cont_pract_Mantener = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_pract='MANTENER')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_pract='MANTENER')) as tot30";
$Cont_pract_Mantener = mysqli_query($conexion, $q_Cont_pract_Mantener);
$row_Cont_pract_Mantener = mysqli_fetch_assoc($Cont_pract_Mantener);
$porcientoCont_pract_Mantener = ($row_Cont_pract_Mantener['tot30']*100)/$row_Conteo['tot'];
?>


<?php //////////////////////////////////CONTENIDOS PRACTICOS(AMPLIAR)///////////////////////////////////////////// ?>

<?php
$q_Cont_pract_Ampliar = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_pract='AMPLIAR')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_pract='AMPLIAR')) as tot31";
$Cont_pract_Ampliar = mysqli_query($conexion, $q_Cont_pract_Ampliar);
$row_Cont_pract_Ampliar = mysqli_fetch_assoc($Cont_pract_Ampliar);
$porcientoCont_pract_Ampliar = ($row_Cont_pract_Ampliar['tot31']*100)/$row_Conteo['tot'];
?>

<?php //////////////////////////////////CONTENIDOS PRACTICOS(AMPLIAR)///////////////////////////////////////////// ?>

<?php
$q_Cont_pract_Imp = "SELECT((SELECT COUNT(*) FROM encuestados_si WHERE generacionA='$gen' AND cont_pract='IMPLEMENTAR PRACTICAS')+(SELECT COUNT(*) FROM encuestados_no WHERE generacionN='$gen' AND cont_pract='IMPLEMENTAR PRACTICAS')) as tot32";
$Cont_pract_Imp = mysqli_query($conexion, $q_Cont_pract_Imp);
$row_Cont_pract_Imp = mysqli_fetch_assoc($Cont_pract_Imp);
$porcientoCont_pract_Imp = ($row_Cont_pract_Imp['tot32']*100)/$row_Conteo['tot'];

$num = ($porcientoCont_pract_Reducir * $row_Conteo['tot'])/100;
$num1 = ($porcientoCont_pract_Actualizar * $row_Conteo['tot'])/100;
$num2 = ($porcientoCont_pract_Mantener * $row_Conteo['tot'])/100;
$num3 = ($porcientoCont_pract_Ampliar * $row_Conteo['tot'])/100;
$num4 = ($porcientoCont_pract_Imp * $row_Conteo['tot'])/100;
?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Sugerencias de los alumnos para los contenidos prácticos <br> De un total de <?php echo $row_Conteo['tot']; ?> de alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Reducir <?php echo round($porcientoCont_pract_Reducir,1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoCont_pract_Reducir,1) ?> ],
            ['Actualizar <?php echo round($porcientoCont_pract_Actualizar,1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porcientoCont_pract_Actualizar,1) ?> ],
            ['Mantener <?php echo round($porcientoCont_pract_Mantener,1) ?> % <br> <?php echo $num2 ?> alumnos', <?php echo round($porcientoCont_pract_Mantener,1) ?> ],
            ['Ampliar <?php echo round($porcientoCont_pract_Ampliar,1) ?> % <br> <?php echo $num3 ?> alumnos', <?php echo round($porcientoCont_pract_Ampliar,1) ?> ],
            ['Implementar practicas <?php echo round($porcientoCont_pract_Imp,1) ?> % <br> <?php echo $num4 ?> alumnos', <?php echo round($porcientoCont_pract_Imp,1) ?> ],


        ]
    }]
});
		</script>
	</body>
</html>
