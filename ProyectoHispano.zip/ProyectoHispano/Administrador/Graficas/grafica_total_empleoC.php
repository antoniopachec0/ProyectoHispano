<?php require_once('../../Conexion/conexion.php') ?>

<?php
$gen = $_POST['gen'];
error_reporting(0);
$q_ConteoC = "SELECT((SELECT COUNT(*) FROM encuestados_si_c WHERE generacionA='$gen')+(SELECT COUNT(*) FROM encuestados_no_c WHERE generacionN='$gen')) as tot79";
$conteoC = mysqli_query($conexion, $q_ConteoC);
$row_ConteoC = mysqli_fetch_assoc($conteoC);
?>

<?php
$q_empleoC = "SELECT COUNT(*) as tot80 FROM encuestados_si_c WHERE generacionA='$gen'";
$empleoC = mysqli_query($conexion, $q_empleoC);
$row_empleoC = mysqli_fetch_assoc($empleoC);
 ?>
 <?php

 $q_noempleoC = "SELECT COUNT(*) as tot81 FROM encuestados_no_c WHERE generacionN='$gen'";
 $noempleoC = mysqli_query($conexion, $q_noempleoC);
 $row_noempleoC = mysqli_fetch_assoc($noempleoC);
	?>
<?php
$porcientoC = ($row_empleoC['tot80']*100)/$row_ConteoC['tot79'];
$porciento2C = ($row_noempleoC['tot81']*100)/$row_ConteoC['tot79'];

$num = ($porcientoC * $row_ConteoC['tot79'])/100;
$num1 = ($porciento2C * $row_ConteoC['tot79'])/100;
 ?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Sistema de Egresados</title>

		<style type="text/css">

		</style>
	</head>
	<body>

<script src="Highcharts/code/highcharts.js"></script>
<script src="Highcharts/code/highcharts-3d.js"></script>
<script src="Highcharts/code/modules/exporting.js"></script>
<script src="Highcharts/code/modules/export-data.js"></script>

<div id="container" style="height: 400px"></div>


		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Reporte de alumnos con empleo y sin empleo de la Fase C <br> De un total de <?php echo $row_ConteoC['tot79']; ?> alumnos encuestados'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Total',
        data: [
            ['Alumnos con empleo <?php echo round($porcientoC, 1) ?> % <br> <?php echo $num ?> alumnos', <?php echo round($porcientoC, 1) ?> ],
            ['Alumnos sin empleo <?php echo round($porciento2C, 1) ?> % <br> <?php echo $num1 ?> alumnos', <?php echo round($porciento2C, 1) ?> ],

        ]
    }]
});
		</script>
	</body>
</html>
