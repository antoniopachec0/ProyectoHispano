<?php require_once('../../Conexion/conexion.php');
session_start();
if ($_SESSION['nivel']!=2){
  header('Location: ../index.php');
}
mysqli_set_charset($conexion, "utf8");
$sql = "SELECT * FROM usuario WHERE matriculau='".$_SESSION['matriculau']."'";
$query = mysqli_query($conexion, $sql);
$fila = mysqli_fetch_assoc($query);
$encontrados = mysqli_num_rows($query);
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="../../CSS/estilo.css">
<link rel="stylesheet" href="../../bootstrap3/css/bootstrap.css">
<link rel="stylesheet" href="../../CSS/jquery-ui.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<title>Sistema de Egresados</title>
<script src="../../JS/validacion.js" type="text/javascript"></script>
<style type="text/css">
#contenedor #login #ingreso table tr .inserta_tablas1 strong {
	color: #990000;
}
h1 {
	color: #990000;
}
.Estilo1 {font-size: 16px}
	.volver{}



</style>
</head>
<body>
<div id="contenedor">
 <div id="cabecera"><center><img src="../../Imagenes/HispanoLogo.png" alt="Sistema de Inventario" border="0" class="imagen"></center>
  <p>&nbsp;</p>
</div><br><br>

<div id="login">
  <h2>ADMINISTRADOR CAPTURE EL AÑO DE EGRESO DE LA GENERACIÓN QUE VA A BUSCAR:</h2><center>
  <!--<a href="../inicio.php" class="link" style="float:right;">Regresar</a>-->
 <br>

<center>
<form action="script_consultasxgenSIC.php" method="POST" name="ingreso" id="ingreso">
  <input type="text" name="buscadorgen" value="" class="form-control" style="width: 200px;" placeholder="Ingresa el año de egreso..."><br>
  <input type="submit" name="buscar" value="Descargar" class="btn btn-primary">

</form>
</center>
</div>

<div id="pie">
<br><br>
<div id="pie">
  <div id="navabajo">
    <a href="menu.php">Volver</a> |
    <a href="../inicio.php">inicio</a>

  </div>
<br>
<br>
<center>
  <strong><p>Panel principal del Administrador.</strong></p>

  <br><br>
</center>
</div>
</div>
</body>
</html>
