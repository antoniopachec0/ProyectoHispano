<?php

header("Content-Type: application/vdn.ms-excel");
date_default_timezone_set("America/Mexico_City");
$nombre = "Reporte_EncuestaC_no_Generacion".date("Y-m-d H:i:s");
header("Content-Disposition: attachment; filename=\"$nombre.xls\"");
header("Cache-Control: max-age=0");

require('../ReporteGlobal/LibreriaExcel/Classes/PHPExcel.php');

$excel = new PHPExcel();
$excel->getProperties()->setCreator('Antonio')->setLastModifiedBy('Antonio')->setTitle('Reporte_de_alumnos');

$excel->setActiveSheetIndex(0);



$pagina = $excel->getActiveSheet();
$pagina->setTitle('Reporte_de_alumnos');
$buscadorgen = $_POST['buscadorgen'];
$mysql = new mysqli('www.universidadhispano.edu.mx', 'univer17', 'gW3bc0El86', 'univer17_egresados');
$mysql->set_charset('utf8');
$statement = $mysql->prepare("SELECT * FROM encuestados_no_c WHERE generacionN='$buscadorgen'");
$statement->execute();
$result = $statement->get_result();
while($row = $result->fetch_array()) $listado[] = $row;

$pagina->setCellValue('A1', 'ID');
$pagina->setCellValue('B1', 'MATRICULA');
$pagina->setCellValue('C1', 'NOMBRE COMPLETO');
$pagina->setCellValue('D1', 'GRUPO');
$pagina->setCellValue('E1', 'FECHA DE NACIMIENTO');
$pagina->setCellValue('F1', 'ESTADO DE NACIMIENTO');
$pagina->setCellValue('G1', 'MUNICIPIO DE NACIMIENTO');
$pagina->setCellValue('H1', 'SEXO');
$pagina->setCellValue('I1', 'NACIONALIDAD');
$pagina->setCellValue('J1', 'CALLE O AVENIDA');
$pagina->setCellValue('K1', 'NUM. INT');
$pagina->setCellValue('L1', 'NUM. EXT');
$pagina->setCellValue('M1', 'COLONIA');
$pagina->setCellValue('N1', 'CIUDAD');
$pagina->setCellValue('O1', 'ESTADO');
$pagina->setCellValue('P1', 'CODIGO POSTAL');
$pagina->setCellValue('Q1', 'TELEFONO FIJO');
$pagina->setCellValue('R1', 'TELEFONO CELULAR');
$pagina->setCellValue('S1', 'CORREO ELECTRONICO');
$pagina->setCellValue('T1', 'FACEBOOK');
$pagina->setCellValue('U1', 'NOMBRE DE UN FAMILIAR');
$pagina->setCellValue('V1', 'PARENTESCO');
$pagina->setCellValue('W1', 'CALLE O AVENIDA');
$pagina->setCellValue('X1', 'NUM. INT. (FAM)');
$pagina->setCellValue('Y1', 'NUM. EXT. (FAM)');
$pagina->setCellValue('Z1', 'COLONIA (FAM)');
$pagina->setCellValue('AA1', 'CIUDAD (FAM)');
$pagina->setCellValue('AB1', 'ESTADO (FAM)');
$pagina->setCellValue('AC1', 'CODIGO POSTAL (FAM)');
$pagina->setCellValue('AD1', 'TELEFONO FIJO (FAM)');
$pagina->setCellValue('AE1', 'TELEFONO CELULAR (FAM)');
$pagina->setCellValue('AF1', 'CORREO ELECTRONICO (FAM)');
$pagina->setCellValue('AG1', 'MATRICULA');
$pagina->setCellValue('AH1', 'MODALIDAD');
$pagina->setCellValue('AI1', 'MES INGRESO');
$pagina->setCellValue('AJ1', 'AÑO INGRESO');
$pagina->setCellValue('AK1', 'MES EGRESO');
$pagina->setCellValue('AL1', 'AÑO EGRESO');
//$pagina->setCellValue('AM1', 'GENERACION');
$pagina->setCellValue('AM1', 'LICENCIATURA DE CURSO');
$pagina->setCellValue('AN1', '¿EL SERVICIO SOCIAL CONTRIBUYO A TU FORMACION PROFESIONAL?');
$pagina->setCellValue('AO1', 'DIFICULTADES PARA CONSEGUIR EMPLEO');
$pagina->setCellValue('AP1', 'RAZONES POR LAS QUE NO TRABAJA');
$pagina->setCellValue('AQ1', 'FECHA DE REGISTRO');
$pagina->setCellValue('AR1', 'GENERACIÓN');

$pagina->getStyle('A1:AR1')->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$pagina->getStyle('A1:AR1')->getFont()->setSize(12);

$pagina->getStyle('A1:AR1')->getFill()
->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
->getStartColor()->setARGB('#8B0000');




for($i = 0; $i < count($listado); $i++){
	$pagina->setCellValue('A'. ($i+2), $listado[$i]['id']);
	$pagina->setCellValue('B'. ($i+2), $listado[$i]['matriculaN']);
	$pagina->setCellValue('C'. ($i+2), $listado[$i]['nombre']);
	$pagina->setCellValue('D'. ($i+2), $listado[$i]['grupo']);
	$pagina->setCellValue('E'. ($i+2), $listado[$i]['fecha_nac']);
	$pagina->setCellValue('F'. ($i+2), $listado[$i]['estado_nac']);
	$pagina->setCellValue('G'. ($i+2), $listado[$i]['municipio']);
	$pagina->setCellValue('H'. ($i+2), $listado[$i]['sexo']);
	$pagina->setCellValue('I'. ($i+2), $listado[$i]['nacionalidad']);
	$pagina->setCellValue('J'. ($i+2), $listado[$i]['calle']);
	$pagina->setCellValue('K'. ($i+2), $listado[$i]['num_int']);
	$pagina->setCellValue('L'. ($i+2), $listado[$i]['num_ext']);
	$pagina->setCellValue('M'. ($i+2), $listado[$i]['colonia']);
	$pagina->setCellValue('N'. ($i+2), $listado[$i]['ciudad']);
	$pagina->setCellValue('O'. ($i+2), $listado[$i]['estado']);
	$pagina->setCellValue('P'. ($i+2), $listado[$i]['codigo']);
	$pagina->setCellValue('Q'. ($i+2), $listado[$i]['telfijo']);
	$pagina->setCellValue('R'. ($i+2), $listado[$i]['telcel']);
	$pagina->setCellValue('S'. ($i+2), $listado[$i]['correo']);
	$pagina->setCellValue('T'. ($i+2), $listado[$i]['face']);
	$pagina->setCellValue('U'. ($i+2), $listado[$i]['nom_fam']);
	$pagina->setCellValue('V'. ($i+2), $listado[$i]['parentesco']);
	$pagina->setCellValue('W'. ($i+2), $listado[$i]['calle_fam']);
	$pagina->setCellValue('X'. ($i+2), $listado[$i]['num_int_fam']);
	$pagina->setCellValue('Y'. ($i+2), $listado[$i]['num_ext_fam']);
	$pagina->setCellValue('Z'. ($i+2), $listado[$i]['colonia_fam']);
	$pagina->setCellValue('AA'. ($i+2), $listado[$i]['ciudad_fam']);
	$pagina->setCellValue('AB'. ($i+2), $listado[$i]['estado_fam']);
	$pagina->setCellValue('AC'. ($i+2), $listado[$i]['codigo_fam']);
	$pagina->setCellValue('AD'. ($i+2), $listado[$i]['telfijo_fam']);
	$pagina->setCellValue('AE'. ($i+2), $listado[$i]['telcel_fam']);
	$pagina->setCellValue('AF'. ($i+2), $listado[$i]['correo_fam']);
	$pagina->setCellValue('AG'. ($i+2), $listado[$i]['matriculaR']);
	$pagina->setCellValue('AH'. ($i+2), $listado[$i]['modalidad']);
	$pagina->setCellValue('AI'. ($i+2), $listado[$i]['mes_ingreso']);
	$pagina->setCellValue('AJ'. ($i+2), $listado[$i]['anio_ingreso']);
	$pagina->setCellValue('AK'. ($i+2), $listado[$i]['mes_egreso']);
	$pagina->setCellValue('AL'. ($i+2), $listado[$i]['anio_egreso']);

	$pagina->setCellValue('AM'. ($i+2), $listado[$i]['lic_egreso']);
	$pagina->setCellValue('AN'. ($i+2), $listado[$i]['serv_social']);
  $pagina->setCellValue('AO'. ($i+2), $listado[$i]['dif']);
    $pagina->setCellValue('AP'. ($i+2), $listado[$i]['razones']);
      $pagina->setCellValue('AQ'. ($i+2), $listado[$i]['fecha_reg']);
$pagina->setCellValue('AR'. ($i+2), $listado[$i]['generacionN']);


}
foreach(range('AA', 'AR') as $columna){
	$pagina->getColumnDimension($columna)->setAutoSize(true);
}


$objWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$objWriter->save('php://output');
