<?php

header("Content-Type: application/vdn.ms-excel");
date_default_timezone_set("America/Mexico_City");
$nombre = "Reporte_EncuestaA_si_Generacion".date("Y-m-d H:i:s");
header("Content-Disposition: attachment; filename=\"$nombre.xls\"");
header("Cache-Control: max-age=0");

require('../ReporteGlobal/LibreriaExcel/Classes/PHPExcel.php');

$excel = new PHPExcel();
$excel->getProperties()->setCreator('Antonio')->setLastModifiedBy('Antonio')->setTitle('Reporte_alumnos');

$excel->setActiveSheetIndex(0);



$pagina = $excel->getActiveSheet();
$pagina->setTitle('Reporte_alumnos');
$buscadorgen = $_POST['buscadorgen'];
$mysql = new mysqli('www.universidadhispano.edu.mx', 'univer17', 'gW3bc0El86', 'univer17_egresados');
$mysql->set_charset('utf8');
$statement = $mysql->prepare("SELECT * FROM encuestados_si WHERE generacionA='$buscadorgen'");
$statement->execute();
$result = $statement->get_result();
while($row = $result->fetch_array()) $listado[] = $row;

$pagina->setCellValue('A1', 'ID');
$pagina->setCellValue('B1', 'MATRICULA');
$pagina->setCellValue('C1', 'NOMBRE COMPLETO');
$pagina->setCellValue('D1', 'GRUPO');
$pagina->setCellValue('E1', 'FECHA DE NACIMIENTO');
$pagina->setCellValue('F1', 'ESTADO DE NACIMIENTO');
$pagina->setCellValue('G1', 'MUNICIPIO DE NACIMIENTO');
$pagina->setCellValue('H1', 'SEXO');
$pagina->setCellValue('I1', 'NACIONALIDAD');
$pagina->setCellValue('J1', 'CALLE O AVENIDA');
$pagina->setCellValue('K1', 'NUM. INT');
$pagina->setCellValue('L1', 'NUM. EXT');
$pagina->setCellValue('M1', 'COLONIA');
$pagina->setCellValue('N1', 'CIUDAD');
$pagina->setCellValue('O1', 'ESTADO');
$pagina->setCellValue('P1', 'CODIGO POSTAL');
$pagina->setCellValue('Q1', 'TELEFONO FIJO');
$pagina->setCellValue('R1', 'TELEFONO CELULAR');
$pagina->setCellValue('S1', 'CORREO ELECTRONICO');
$pagina->setCellValue('T1', 'FACEBOOK');
$pagina->setCellValue('U1', 'NOMBRE DE UN FAMILIAR');
$pagina->setCellValue('V1', 'PARENTESCO');
$pagina->setCellValue('W1', 'CALLE O AVENIDA');
$pagina->setCellValue('X1', 'NUM. INT. (FAM)');
$pagina->setCellValue('Y1', 'NUM. EXT. (FAM)');
$pagina->setCellValue('Z1', 'COLONIA (FAM)');
$pagina->setCellValue('AA1', 'CIUDAD (FAM)');
$pagina->setCellValue('AB1', 'ESTADO (FAM)');
$pagina->setCellValue('AC1', 'CODIGO POSTAL (FAM)');
$pagina->setCellValue('AD1', 'TELEFONO FIJO (FAM)');
$pagina->setCellValue('AE1', 'TELEFONO CELULAR (FAM)');
$pagina->setCellValue('AF1', 'CORREO ELECTRONICO (FAM)');
$pagina->setCellValue('AG1', 'MATRICULA');
$pagina->setCellValue('AH1', 'MODALIDAD');
$pagina->setCellValue('AI1', 'MES INGRESO');
$pagina->setCellValue('AJ1', 'AÑO INGRESO');
$pagina->setCellValue('AK1', 'MES EGRESO');
$pagina->setCellValue('AL1', 'AÑO EGRESO');
//$pagina->setCellValue('AM1', 'GENERACION');
$pagina->setCellValue('AM1', 'LICENCIATURA DE CURSO');
$pagina->setCellValue('AN1', '¿EL SERVICIO SOCIAL CONTRIBUYO A TU FORMACION PROFESIONAL?');
$pagina->setCellValue('AO1', 'NOMBRE DE LA INSTITUCIÓN');
$pagina->setCellValue('AP1', 'SECTOR');
$pagina->setCellValue('AQ1', 'SECTOR SECTOR ECONÓMICO AL QUE PERTENECE LA INSTITUCIÓN O EMPRESA');
$pagina->setCellValue('AR1', 'NOMBRE DEL JEFE INMEDIATO');
$pagina->setCellValue('AS1', 'PUESTO DEL JEFE INMEDIATO:');
$pagina->setCellValue('AT1', 'DIRECCION DE LA EMPRESA: CALLE O AV.');
$pagina->setCellValue('AU1', 'NUM. EXT');
$pagina->setCellValue('AV1', 'COLONIA');
$pagina->setCellValue('AW1', 'CIUDAD');
$pagina->setCellValue('AX1', 'ESTADO');
$pagina->setCellValue('AY1', 'CODIGO POSTAL');
$pagina->setCellValue('AZ1', 'TELEFONO FIJO');
$pagina->setCellValue('BA1', 'TELEFONO CELULAR');
$pagina->setCellValue('BB1', 'CORREO ELECTRONICO');
$pagina->setCellValue('BC1', 'FACEBOOK');
$pagina->setCellValue('BD1', 'TIPO DE CONTRATO');
$pagina->setCellValue('BE1', 'NOMBRE DEL PUESTO QUE OCUPAS');
$pagina->setCellValue('BF1', 'MES INGRESO A LABORAR');
$pagina->setCellValue('BG1', 'AÑO INGRESO A LABORAR');
$pagina->setCellValue('BH1', 'HORAS DE TRABAJO QUE CUBRES A LA SEMANA');
$pagina->setCellValue('BI1', 'SALARIO MENSUAL NETO');
$pagina->setCellValue('BJ1', 'PRINCIPAL REQUISITO PARA LABORAR');
$pagina->setCellValue('BK1', 'DESCRIBE TUS FUNCIONES LABORALES');
$pagina->setCellValue('BL1', '¿TUS FUNCIONES LABORALES, TIENEN RELACION CON TU FORMACION A NIVEL LICENCIATURA?');
$pagina->setCellValue('BM1', 'FACTORES QUE INFLUYERON PARA CONSEGUIR EMPLEO');
$pagina->setCellValue('BN1', '¿COMO EVALUAS EL PLAN DE ESTUDIOS QUE CURSASTE?');
$pagina->setCellValue('BO1', '¿QUE MODIFICACIONES LE HARIAS A LOS CONTENIDOS TEORICOS?');
$pagina->setCellValue('BP1', '¿QUE MODIFICACIONES LE HARIAS A LOS CONTENIDOS METODOLOGICOS?');
$pagina->setCellValue('BQ1', '¿QUE MODIFICACIONES LE HARIAS A LAS TECNICAS RELACIONADAS CON LA CARRERA?');
$pagina->setCellValue('BR1', '¿QUE MODIFICACIONES LE HARIAS A LOS CONTENIDOS PRACTICOS?');
$pagina->setCellValue('BS1', '¿EN QUE AREA HARIAS UNA PROPUESTA PARA MEJORAR EL PLAN DE ESTUDIOS QUE CURSASTE?');
$pagina->setCellValue('BT1', 'EXPLICA BREVEMENTE LA RESPUESTA');
$pagina->setCellValue('BU1', 'EN ESCALA DEL 5 AL 10, ¿COMO ES EL NIVEL DE ENSEÑANZA DE LOS MAESTROS?');
$pagina->setCellValue('BV1', 'EN ESCALA DEL 5 AL 10, ¿COMO ES EL NIVEL DE SATISFACCION DE ACTIVIDADES DE CLASE CON LA REALIDAD?');
$pagina->setCellValue('BW1', 'EN ESCALA DEÑ 5 AL 10, ¿COMO ES EL NIVEL DE SATISFACCION DE LOS APRENDIZAJES LOGRADOS?');
$pagina->setCellValue('BX1', 'EN ESCALA DEL 5 AL 10, ¿COMO ES EL NIVEL DE SATISFACCION CON LA ORIENTACION DE LOS MAESTROS?');
$pagina->setCellValue('BY1', 'EN ESCALA DEL 5 AL 10, ¿COMO ES EL NIVEL DE SATISFACCION CON LOS RECURSOS DE APOYO DE LOS MAESTROS EN CLASE?');
$pagina->setCellValue('BZ1', 'HABILIDAD PARA LA COMUNICACION VERBAL');
$pagina->setCellValue('CA1', 'HABILIDAD PARA LA COMUNICACION ESCRITA');
$pagina->setCellValue('CB1', 'HABILIDADES DIGITALES EN EL MANEJO DE SOFTWARE PROPIO DE LA CARRERA');
$pagina->setCellValue('CC1', 'FACILIDAD EN LAS RELACIONES INTERPERSONALES');
$pagina->setCellValue('CD1', 'HABILIDAD EN EL PENSAMIENTO MATEMATICO');
$pagina->setCellValue('CE1', 'HABILIDAD EN EL PENSAMIENTO LOGICO');
$pagina->setCellValue('CF1', 'HABILIDAD PARA LA CAPACIDAD ANALITICA');
$pagina->setCellValue('CG1', 'HABILIDAD PARA LA CAPACIDAD ARGUMENTATIVA');
$pagina->setCellValue('CH1', 'AUTOCONOCIMIENTO');
$pagina->setCellValue('CI1', 'AL EGRESAR DE LA LICENCIATURA, ¿QUE ESTUDIOS TE INTEREZARIA REALIZAR?');
$pagina->setCellValue('CJ1', '¿CUANTAS HORAS LE INVERTIRIAS A TU FORMACION CONTINUA?');
$pagina->setCellValue('CK1', '¿EN QUE MODALIDAD TE GUSTARIA CONTINUAR TU FORMACION PROFESIONAL?');
$pagina->setCellValue('CL1', '¿EN QUE AREA TE GUSTARIA CONTINUAR TU FORMACION PROFESIONAL?');
$pagina->setCellValue('CM1', 'ASPECTOS EN QUE TE FORMÓ LA UNIVERSIDAD HISPANO');
$pagina->setCellValue('CN1', 'FECHA DE REGISTRO');
$pagina->setCellValue('CO1', 'GENERACION');

$pagina->getStyle('A1:CO1')->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$pagina->getStyle('A1:CO1')->getFont()->setSize(12);

$pagina->getStyle('A1:CO1')->getFill()
->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
->getStartColor()->setARGB('#8B0000');




for($i = 0; $i < count($listado); $i++){
	$pagina->setCellValue('A'. ($i+2), $listado[$i]['id']);
	$pagina->setCellValue('B'. ($i+2), $listado[$i]['matriculaA']);
	$pagina->setCellValue('C'. ($i+2), $listado[$i]['nombre']);
	$pagina->setCellValue('D'. ($i+2), $listado[$i]['grupo']);
	$pagina->setCellValue('E'. ($i+2), $listado[$i]['fecha_nac']);
	$pagina->setCellValue('F'. ($i+2), $listado[$i]['estado_nac']);
	$pagina->setCellValue('G'. ($i+2), $listado[$i]['municipio']);
	$pagina->setCellValue('H'. ($i+2), $listado[$i]['sexo']);
	$pagina->setCellValue('I'. ($i+2), $listado[$i]['nacionalidad']);
	$pagina->setCellValue('J'. ($i+2), $listado[$i]['calle']);
	$pagina->setCellValue('K'. ($i+2), $listado[$i]['num_int']);
	$pagina->setCellValue('L'. ($i+2), $listado[$i]['num_ext']);
	$pagina->setCellValue('M'. ($i+2), $listado[$i]['colonia']);
	$pagina->setCellValue('N'. ($i+2), $listado[$i]['ciudad']);
	$pagina->setCellValue('O'. ($i+2), $listado[$i]['estado']);
	$pagina->setCellValue('P'. ($i+2), $listado[$i]['codigo']);
	$pagina->setCellValue('Q'. ($i+2), $listado[$i]['telfijo']);
	$pagina->setCellValue('R'. ($i+2), $listado[$i]['telcel']);
	$pagina->setCellValue('S'. ($i+2), $listado[$i]['correo']);
	$pagina->setCellValue('T'. ($i+2), $listado[$i]['face']);
	$pagina->setCellValue('U'. ($i+2), $listado[$i]['nom_fam']);
	$pagina->setCellValue('V'. ($i+2), $listado[$i]['parentesco']);
	$pagina->setCellValue('W'. ($i+2), $listado[$i]['calle_fam']);
	$pagina->setCellValue('X'. ($i+2), $listado[$i]['num_int_fam']);
	$pagina->setCellValue('Y'. ($i+2), $listado[$i]['num_ext_fam']);
	$pagina->setCellValue('Z'. ($i+2), $listado[$i]['colonia_fam']);
	$pagina->setCellValue('AA'. ($i+2), $listado[$i]['ciudad_fam']);
	$pagina->setCellValue('AB'. ($i+2), $listado[$i]['estado_fam']);
	$pagina->setCellValue('AC'. ($i+2), $listado[$i]['codigo_fam']);
	$pagina->setCellValue('AD'. ($i+2), $listado[$i]['telfijo_fam']);
	$pagina->setCellValue('AE'. ($i+2), $listado[$i]['telcel_fam']);
	$pagina->setCellValue('AF'. ($i+2), $listado[$i]['correo_fam']);
	$pagina->setCellValue('AG'. ($i+2), $listado[$i]['matriculaR']);
	$pagina->setCellValue('AH'. ($i+2), $listado[$i]['modalidad']);
	$pagina->setCellValue('AI'. ($i+2), $listado[$i]['mes_ingreso']);
	$pagina->setCellValue('AJ'. ($i+2), $listado[$i]['anio_ingreso']);
	$pagina->setCellValue('AK'. ($i+2), $listado[$i]['mes_egreso']);
	$pagina->setCellValue('AL'. ($i+2), $listado[$i]['anio_egreso']);

	$pagina->setCellValue('AM'. ($i+2), $listado[$i]['lic_egreso']);
	$pagina->setCellValue('AN'. ($i+2), $listado[$i]['serv_social']);

	$pagina->setCellValue('AO'. ($i+2), $listado[$i]['nom_inst']);
	$pagina->setCellValue('AP'. ($i+2), $listado[$i]['sector']);
	$pagina->setCellValue('AQ'. ($i+2), $listado[$i]['sector_eco']);
	$pagina->setCellValue('AR'. ($i+2), $listado[$i]['nom_jefe']);
	$pagina->setCellValue('AS'. ($i+2), $listado[$i]['puesto_jefe']);
	$pagina->setCellValue('AT'. ($i+2), $listado[$i]['dire_empresa']);
	$pagina->setCellValue('AU'. ($i+2), $listado[$i]['num_ext_empresa']);
	$pagina->setCellValue('AV'. ($i+2), $listado[$i]['col_empresa']);
	$pagina->setCellValue('AW'. ($i+2), $listado[$i]['cd_empresa']);
	$pagina->setCellValue('AX'. ($i+2), $listado[$i]['est_empresa']);

	$pagina->setCellValue('AY'. ($i+2), $listado[$i]['codigo_emp']);
	$pagina->setCellValue('AZ'. ($i+2), $listado[$i]['tel_fijo_emp']);
	$pagina->setCellValue('BA'. ($i+2), $listado[$i]['tel_cel_emp']);
	$pagina->setCellValue('BB'. ($i+2), $listado[$i]['correo_empre']);
	$pagina->setCellValue('BC'. ($i+2), $listado[$i]['face_empre']);
	$pagina->setCellValue('BD'. ($i+2), $listado[$i]['contrato']);
	$pagina->setCellValue('BE'. ($i+2), $listado[$i]['puesto']);
	$pagina->setCellValue('BF'. ($i+2), $listado[$i]['mes_laborar']);
	$pagina->setCellValue('BG'. ($i+2), $listado[$i]['anio_laborar']);
	$pagina->setCellValue('BH'. ($i+2), $listado[$i]['horas_trabajo']);
	$pagina->setCellValue('BI'. ($i+2), $listado[$i]['salario']);
	$pagina->setCellValue('BJ'. ($i+2), $listado[$i]['requisito']);
	$pagina->setCellValue('BK'. ($i+2), $listado[$i]['describes']);
	$pagina->setCellValue('BL'. ($i+2), $listado[$i]['funciones']);
	$pagina->setCellValue('BM'. ($i+2), $listado[$i]['fact']);

	$pagina->setCellValue('BN'. ($i+2), $listado[$i]['como_evaluas']);
	$pagina->setCellValue('BO'. ($i+2), $listado[$i]['cont_teorico']);
	$pagina->setCellValue('BP'. ($i+2), $listado[$i]['cont_meto']);
	$pagina->setCellValue('BQ'. ($i+2), $listado[$i]['tec_carrera']);
	$pagina->setCellValue('BR'. ($i+2), $listado[$i]['cont_pract']);
	$pagina->setCellValue('BS'. ($i+2), $listado[$i]['propuesta']);
	$pagina->setCellValue('BT'. ($i+2), $listado[$i]['explica_breve']);
	$pagina->setCellValue('BU'. ($i+2), $listado[$i]['nivel_ense_maestros']);
	$pagina->setCellValue('BV'. ($i+2), $listado[$i]['nivel_satisfaccion_actividades']);
	$pagina->setCellValue('BW'. ($i+2), $listado[$i]['nivel_satisfaccion_aprendizajes']);
	$pagina->setCellValue('BX'. ($i+2), $listado[$i]['nivel_satisfaccion_asesoria']);
	$pagina->setCellValue('BY'. ($i+2), $listado[$i]['nivel_satisfaccion_recursos']);
	$pagina->setCellValue('BZ'. ($i+2), $listado[$i]['hab_com_verbal']);
	$pagina->setCellValue('CA'. ($i+2), $listado[$i]['hab_com_escrita']);
	$pagina->setCellValue('CB'. ($i+2), $listado[$i]['hab_dig_soft']);
	$pagina->setCellValue('CC'. ($i+2), $listado[$i]['fac_rel_personales']);
	$pagina->setCellValue('CD'. ($i+2), $listado[$i]['pensa_matematico']);
	$pagina->setCellValue('CE'. ($i+2), $listado[$i]['pensa_logico']);
	$pagina->setCellValue('CF'. ($i+2), $listado[$i]['cap_analitica']);
	$pagina->setCellValue('CG'. ($i+2), $listado[$i]['cap_argumentativo']);
	$pagina->setCellValue('CH'. ($i+2), $listado[$i]['autoconocimiento']);
	$pagina->setCellValue('CI'. ($i+2), $listado[$i]['que_intentaria_realizar']);
	$pagina->setCellValue('CJ'. ($i+2), $listado[$i]['hrs_inv_form_cont']);
	$pagina->setCellValue('CK'. ($i+2), $listado[$i]['modalidad_form_cont']);
	$pagina->setCellValue('CL'. ($i+2), $listado[$i]['area_form_cont']);
	$pagina->setCellValue('CM'. ($i+2), $listado[$i]['aspectos']);
	$pagina->setCellValue('CN'. ($i+2), $listado[$i]['fecha_reg']);
  $pagina->setCellValue('CO'. ($i+2), $listado[$i]['generacionA']);
}

foreach(range('AA', 'CO') as $columna){
	$pagina->getColumnDimension($columna)->setAutoSize(true);
}


$objWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$objWriter->save('php://output');
