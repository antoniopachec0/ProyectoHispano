<?php require_once('../../Conexion/conexion.php');
session_start();
if ($_SESSION['nivel']!=2){
  header('Location: ../index.php');
}
mysqli_set_charset($conexion, "utf8");
$sql = "SELECT * FROM usuario WHERE matriculau='".$_SESSION['matriculau']."'";
$query = mysqli_query($conexion, $sql);
$fila = mysqli_fetch_assoc($query);
$encontrados = mysqli_num_rows($query);
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="../../CSS/estilo.css">
<link rel="stylesheet" href="../../bootstrap3/css/bootstrap.css">
<link rel="stylesheet" href="../../CSS/jquery-ui.css">

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<title>Sistema de Egresados</title>



<script src="../../JS/validacion.js" type="text/javascript"></script>
<style type="text/css">
#contenedor #login #ingreso table tr .inserta_tablas1 strong {
	color: #990000;
}
h1 {
	color: #990000;
}
.Estilo1 {font-size: 16px}
h4{
  color: #91010e;
  font-size: 12pt;
}



</style>
</head>
<body>
<div id="contenedor">
 <div id="cabecera"><center><img src="../../Imagenes/HispanoLogo.png" alt="Sistema de Inventario" border="0" class="imagen"></center>
  <p>&nbsp;</p>
</div><br><br>
<h2>Administrador</h2>
  <!--<a href="../inicio.php" class="link" style="float:right;">Regresar</a>-->
 <br>
 <div id="lateral">
 <h2 class="titlat">Encuesta Fase A</h2>
 <div id="otras" class="cuerpolateral">
 <ul>
 <li><center><a href="consultasxgen.php">Empleados</a></center></li>
 <li><center><a href="consultasxgenNOA.php">Desempleados</a></center></li>
 </ul>
 <h2 class="titlat">Encuesta Fase B</h2>

 <ul>
   <li><center><a href="consultasxgenSIB.php">Empleados</a></center></li>
   <li><center><a href="consultasxgenNOB.php">Desempleados</a></center></li>
 </ul>
 <h2 class="titlat">Encuesta Fase C</h2>
 <ul>
   <li><center><a href="consultasxgenSIC.php">Empleados</a></center></li>
   <li><center><a href="consultasxgenNOC.php">Desempleados</a></center></li>
 </ul>
 </div>
</div>

<div id="cuerpo">
  <h2>INSTRUCCIONES</h2>
  <center><h4>En este módulo en especial podrá navegar por la parte lateral de su pantalla, verá un menu que estará <br> dividio por sección dependiendo la fase de encuesta que deseé consultar <br> al dar click en cualquier enlace lo dirigirá a un buscador para realizar la descarga correspondiente a generaciones</h4></center>
<br><br>
  <div id="navabajo">

    <a href="../inicio.php">Portada</a>

  </div>
</div>





<div id="pie">
<br>

<br>
<br>
<center>
  <strong><p>Panel principal del Administrador.</strong></p>

  <br><br>
</center>
</div>
</div>
</body>
</html>
