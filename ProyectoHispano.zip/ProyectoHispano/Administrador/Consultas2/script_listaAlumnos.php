<?php
header("Content-Type: text/html;charset=utf-8");
    require_once('../../Conexion/conexion.php');

    $salida = "";
    $query = "SELECT id, matriculau,nombre,grupo, generacion FROM usuario ORDER BY grupo DESC";

    if(isset($_POST['consulta'])){
        $lista = mysqli_real_escape_string($conexion, $_POST['consulta']);
        $query = "SELECT id, matriculau, nombre, grupo, generacion FROM usuario WHERE id LIKE '%".$lista."%' OR matriculau LIKE '%".$lista."%' OR nombre LIKE '%".$lista."%' OR grupo LIKE '%".$lista."%' OR generacion LIKE '%".$lista."%'";
    }
    $resultado = mysqli_query($conexion, $query);
	$row_ver = mysqli_fetch_assoc($resultado);
	$filas = mysqli_num_rows($resultado);

	$query_respuestas = "SELECT * FROM encuestados_si";
	$respuestas = mysqli_query($conexion, $query_respuestas);
	$row_respuestas = mysqli_fetch_assoc($respuestas);
	$totalRows_respuestas = mysqli_num_rows($respuestas);

?>

<table class="table table-bordered" width='950' border='1' align='center'>
            <tr>


                  <td class='Estilo1'><div align='center'>MATRICULA</td>
                <td class='Estilo1'><div align='center'>NOMBRE COMPLETO</td>
                <td class='Estilo1'><div align='center'>GRUPO</td>
                  <td class='Estilo1'><div align='center'>GENERACIÓN</td>
                <td colspan="2" class='Estilo1'><div align='center'>OPERACIONES</td>

            </tr>
              <?php do { ?>
               <tr>


                <td height='25' class='Estilo3'><?php echo $row_ver['matriculau'];?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['nombre']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['grupo']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['generacion']; ?></td>
                <td height='25' class='Estilo3'><a href="../Operaciones/modificar_usuarios.php?id=<?php echo $row_ver['id']; ?>"><img src="../../Imagenes/editar.png">&nbsp;Editar</a></td>
                <td height='25' class='Estilo3'><a href="../Operaciones/eliminar_usuario.php?matriculau=<?php echo $row_ver['matriculau']; ?>" onclick="return confirm('¿Esta seguro de eliminar a este usuario? \n NOTA: No podra recuperarlo nuevamente)"><img src="../../Imagenes/eliminar.png">&nbsp;Eliminar</a></td>

            </tr>
          <?php } while($row_ver = mysqli_fetch_assoc($resultado));  ?>
</table>
