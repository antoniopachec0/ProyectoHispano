<?php
    header("Content-Type: text/html;charset=utf-8");
    require_once('../../Conexion/conexion.php');

    $salida = "";
    $query = "SELECT matriculaA,nombre,grupo, generacionA FROM encuestados_si ORDER BY id ASC";

    if(isset($_POST['consulta'])){
        $lista = mysqli_real_escape_string($conexion, $_POST['consulta']);
        $query = "SELECT matriculaA, nombre, grupo, generacionA FROM encuestados_si WHERE matriculaA LIKE '%".$lista."%' OR nombre LIKE '%".$lista."%' OR grupo LIKE '%".$lista."%' OR generacionA LIKE '%".$lista."%'";
    }
    $resultado = mysqli_query($conexion, $query);
    $row_ver = mysqli_fetch_assoc($resultado);
	  $totalRows_resultado = mysqli_num_rows($resultado);

?>

<table class="table table-bordered" width='800' border='1' align='center'>
            <tr>

                <td class='Estilo1'><div align='center'>MATRICULA</td>
                <td class='Estilo1'><div align='center'>NOMBRE COMPLETO</td>
                <td class='Estilo1'><div align='center'>GRUPO</td>
                  <td class='Estilo1'><div align='center'>GENERACIÓN</td>
                <td class='Estilo1'><div align='center'>IMPRESIÓN</td>
            </tr>
              <?php do { ?>
               <tr>
                <td height='25' class='Estilo3'><a href="../ver_respuestas.php?matriculaA=<?php echo $row_ver['matriculaA']; ?>"><?php echo $row_ver['matriculaA']; ?></a></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['nombre']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['grupo']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['generacionA']; ?></td>
                <td height='25' class='Estilo3'><a href="reimprimirA.php?matriculaA=<?php echo $row_ver['matriculaA']; ?>">Reimprimir comprobante</a></td>

            </tr>
          <?php } while($row_ver = mysqli_fetch_assoc($resultado));  ?>
</table>
