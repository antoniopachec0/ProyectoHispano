<?php
ob_start();
ob_clean();
flush();
error_reporting(E_ALL & ~E_NOTICE);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
header("Content-Type: text/html;charset=utf-8");
require_once('../../../PDF/lib/pdf/mpdf.php');
require_once('../../../Conexion/conexion.php');
session_start();
if ($_SESSION['nivel']!=2){
  header('Location: ../../../index2.php');
}
mysqli_set_charset($conexion, "utf8");
$sql = "SELECT * FROM usuario WHERE matriculau='".$_SESSION['matriculau']."'";
$query = mysqli_query($conexion, $sql);
$fila = mysqli_fetch_assoc($query);
$encontrados = mysqli_num_rows($query);

$matriculaN = $_REQUEST["matriculaN"];
$query_traerDatos = "SELECT nombre, matriculaN FROM encuestados_no WHERE matriculaN='$matriculaN'";
$traerDatos = mysqli_query($conexion, $query_traerDatos);
$row_traerDatos = mysqli_fetch_assoc($traerDatos);
$totalRows_traerDatos = mysqli_num_rows($traerDatos);
 ?>
<?php
 $html .= '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
 <html xmlns="http://www.w3.org/1999/xhtml">
 <head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 <link rel="stylesheet" href="../../../CSS/estilo.css">
 <link rel="stylesheet" href="../../../bootstrap3/css/bootstrap.css">
 <link rel="stylesheet" href="../../../CSS/jquery-ui.css">
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <script src="../../../JS/jquery-3.3.1.js"></script>
 <script src="../../../JS/jquery-ui.js"></script>
 <title></title>
 <script src="../JS/../validacion.js" type="text/javascript"></script>
 <style type="text/css">
 #contenedor #login #ingreso table tr .inserta_tablas1 strong {
 	color: #990000;
 }
 h1 {
 	color: #990000;
 }
 	.Estilo {font-size: 11pt;}
 	.Estilo1 {font-size: 11pt; background: #FFF; color: #000; text-align: center;}
  span{
    padding: 15px; text-align:center;
  }
 </style>
</head>
<body>
<div id="contenedor">
<div id="cabecera"><center><img src="../../../Imagenes/HispanoLogo.png"  alt="Sistema de Egresados" border="0" class="imagen" /></center>
  <p>&nbsp;</p>
</div><br>
<p><span>ESTIMADO ALUMNO (A) EGRESADO (A):'.$row_traerDatos['nombre'].'<br><br>CON NÚMERO DE MATRÍCULA: '.$row_traerDatos['matriculaN'].' <br><br>
 ESTE DOCUMENTO TE SERVIRA COMO APELACIÓN Y COMPROBANTE DE QUE CULMINASTE CON LA FASE A DEL PROCESO DE SEGUIMIENTO DE EGRESADOS</span></p>
<br><br><br><br>
<center>
</center>
</body>
</html>';
ob_end_clean();
$mpdf = new mPDF('R','A4', 11,'Arial');
$mpdf->AddPage();
$mpdf->writeHTML($html);
//$mpdf->writeHTML($html1);
$mpdf->Output('reporte.pdf', 'I');
?>
