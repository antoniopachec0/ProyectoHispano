<?php
    header("Content-Type: text/html;charset=utf-8");
    require_once('../../../Conexion/conexion.php');

    $salida = "";
    $query = "SELECT matriculaN,nombre,grupo, generacionN FROM encuestados_no ORDER BY id ASC";

    if(isset($_POST['consulta'])){
        $lista = mysqli_real_escape_string($conexion, $_POST['consulta']);
        $query = "SELECT matriculaN, nombre, grupo, generacionN FROM encuestados_no WHERE matriculaN LIKE '%".$lista."%' OR nombre LIKE '%".$lista."%' OR grupo LIKE '%".$lista."%' OR generacionN LIKE '%".$lista."%'";
    }
    $resultado = mysqli_query($conexion, $query);
    $row_ver = mysqli_fetch_assoc($resultado);
	  $totalRows_resultado = mysqli_num_rows($resultado);

?>

<table class="table table-bordered" width='800' border='1' align='center'>
            <tr>

                <td class='Estilo1'><div align='center'>MATRICULA</td>
                <td class='Estilo1'><div align='center'>NOMBRE COMPLETO</td>
                <td class='Estilo1'><div align='center'>GRUPO</td>
                  <td class='Estilo1'><div align='center'>GENERACIÓN</td>
                 <td class='Estilo1'><div align='center'>IMPRESIÓN</td>
            </tr>
              <?php do { ?>
               <tr>
                <td height='25' class='Estilo3'><a href="../../RespuestasInd/ver_respuestasNo.php?matriculaN=<?php echo $row_ver['matriculaN']; ?>"><?php echo $row_ver['matriculaN']; ?></a></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['nombre']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['grupo']; ?></td>
                <td height='25' class='Estilo3'><?php echo $row_ver['generacionN']; ?></td>
                <td class='Estilo3'><div align='center'><a href="reimprimirNoA.php?matriculaN=<?php echo $row_ver["matriculaN"] ?>">Reimprimir comprobante</a></td>

            </tr>
          <?php } while($row_ver = mysqli_fetch_assoc($resultado));  ?>
</table>
