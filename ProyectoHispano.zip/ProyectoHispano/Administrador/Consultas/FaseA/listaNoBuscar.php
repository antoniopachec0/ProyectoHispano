<?php require_once('../../../Conexion/conexion.php');
session_start();
if ($_SESSION['nivel']!=2){
  header('Location: ../../index.php');
}
mysqli_set_charset($conexion, "utf8");
$sql = "SELECT * FROM usuario WHERE matriculau='".$_SESSION['matriculau']."'";
$query = mysqli_query($conexion, $sql);
$fila = mysqli_fetch_assoc($query);
$encontrados = mysqli_num_rows($query);
?>
<?php
$query_Activos_Login_Usuario = "SELECT * FROM usuario WHERE nivel='1' ORDER BY id ASC";
$Activos_Login_Usuario = mysqli_query($conexion, $query_Activos_Login_Usuario);
$row_Activos_Login_Usuario = mysqli_fetch_assoc($Activos_Login_Usuario);
$totalRows_Activos_Login_Usuario = mysqli_num_rows($Activos_Login_Usuario);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sistema</title>
<link href="../../../CSS/estilo.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../../../bootstrap3/css/bootstrap.css">
<link rel="stylesheet" href="../../../CSS/jquery-ui.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">


<style>
    .enlacenav1{
        padding: 6px 25px;
		background: #FFFFAB;
        border: 1px solid #1161B0;
        color: black;
        border-radius: 4px;
        text-decoration: none;
    }
	.Estilo1 {font-size: 12px; background: #91010e; color: #FFF; text-align: center;}
	.Estilo3 {font-size: 12px; background: #FFF; color: #000000; text-align: center;}
	.Estilo {font-size: 16px;}
</style>

</head>

<body>
<div id="borde">
<div id="contenedor">

<div id="cabecera">
  <img src="../../../Imagenes/HispanoLogo.png"  alt="Sistema de Inventario" border="0" class="imagen" /></div>
  <div id="cuerpo1">
  <br><br><br>
 <h2>Lista de alumnos</h2>

 <br></div>

<p align="center">Haga clic en sobre el enlace para ver todas las respuestas del alumno seleccionado</p>
<br>

<center>
 <div id="buscador">
    <strong><span class="Estilo">Buscar</span>:</strong>
    <input type="text" name="caja_busqueda" id="caja_busqueda" style="width: 205px; height: 20px; font-size: 10pt;">
 </div>
 <br>

 <div id="boxLista">
 <div id="datos">

 </div>
 </div>

	</center>
  <a href="../../inicio.php" class="link" style="float:left;">Regresar</a>
  <div id="pie">
  <p align="center"></p>
</div>
<p>&nbsp;</p>
<script src="../../../JS/jquery-3.3.1.min.js"></script>
<script src="listaNoBuscar.js">

</script>
</body>
</html>
